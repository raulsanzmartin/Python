{
    'name': 'propiedades',
    'summary': 'Modulo de gestion de propiedades inmobiliarias',
    'description': "Propiedades Inmobiliarias",
    'depends': [
        'base',
    ],
    'data':[
        'views/rsm_propiedades_inmuebles_views.xml',
        'views/rsm_inmuebles_tipos_views.xml',
        'views/rsm_inmuebles_etiquetas_views.xml',
        'views/rsm_inmuebles_ofertas_views.xml',
        'views/rsm_propiedades_menus.xml',
        'security/ir.model.access.csv',
    ],
    'application': True
}