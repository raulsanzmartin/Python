from odoo import fields,models
from datetime import timedelta
from odoo.exceptions import UserError,ValidationError
class rsm_tipos_inmuebles(models.Model):
    _name = "tipos.inmuebles"
    _description = "Modelo para los tipos de propiedades inmobiliarias"

    name = fields.Char(string = 'Nombre',required = True)

    _sql_constraints = [('check_name', 'unique(name)',
                        'El nombre del TIPO DE PROPIEDAD debe ser unico')]