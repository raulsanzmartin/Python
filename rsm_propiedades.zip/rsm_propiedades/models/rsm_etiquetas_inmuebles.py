from odoo import fields,models
from odoo.exceptions import UserError,ValidationError

class rsm_etiquetas_inmuebles(models.Model):
    _name = "etiquetas.inmuebles"
    _description = "Modelo para las etiquetas que califican las propiedades inmobiliarias"

    name = fields.Char(string = 'Nombre',required = True)

    _sql_constraints = [('check_name', 'unique(name)',
                         'El nombre de la ETIQUETA DE PROPIEDAD debe ser unico')]