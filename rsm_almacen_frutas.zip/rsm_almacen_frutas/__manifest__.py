{
    'name': 'Almacén de frutas RSM',
    'summary': 'Modulo de gestión de compraventa en almacén de frutas',
    'description': "Gestión de la compraventa de frutas, incluyendo la administración de lotes, productos, características de los lotes y ventas.",
    'depends': [
        'base',
    ],
    'data': [
        'views/rsm_lotes_views.xml',
        'views/rsm_productos_views.xml',
        'views/rsm_caracteristicas_lotes_views.xml',
        'views/rsm_ventas_lotes_views.xml',
        'views/rsm_menus.xml',
        'views/rsm_res_users_views.xml',
        'security/ir.model.access.csv',
        # Actualización de nombres de archivos en la carpeta reports
        'reports/rsm_lotes_reports.xml',
        'reports/rsm_lotes_templates.xml',
        'reports/rsm_ventas_lotes_reports.xml',
        'reports/rsm_ventas_lotes_templates.xml',
    ],
    'application': True
}
