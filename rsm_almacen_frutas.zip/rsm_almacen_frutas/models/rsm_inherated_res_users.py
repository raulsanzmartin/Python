from odoo import fields, models

class rsm_InheritedResUsers(models.Model):
    _inherit = "res.users"

    ventas_ids = fields.One2many("rsm.ventas_lotes", "cliente_id", string="Ventas de Lotes")
