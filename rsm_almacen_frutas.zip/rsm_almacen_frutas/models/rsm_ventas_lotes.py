from odoo import models, fields, api
from datetime import date

class rsm_ventas_lotes(models.Model):
    _name = "rsm.ventas_lotes"
    _description = "Modelo para las ventas de lotes de productos"

    fecha_venta = fields.Date(string="Fecha de Venta", default=lambda self: fields.Date.context_today(self), required=True)
    cantidad_vendida = fields.Float(string="Cantidad Vendida", required=True)
    precio_total = fields.Float(string="Precio Total", compute="_compute_precio_total", store=True)
    state = fields.Selection([
        ('vendido', 'Vendido'),
        ('facturado', 'Facturado'),
        ('cancelado', 'Cancelado')
    ], string='Estado', default='vendido', readonly=True)
    cliente_id = fields.Many2one("res.partner", required=True, string="Cliente")
    lote_id = fields.Many2one("rsm.lotes", required=True, string="Lote", ondelete="cascade")
    usuario_id=fields.Many2one('res.users',string='Usuario',default=lambda self: self.env.user)

    @api.depends('cantidad_vendida', 'lote_id.precio_venta_unidad')
    def _compute_precio_total(self):
        for record in self:
            record.precio_total = record.cantidad_vendida * record.lote_id.precio_venta_unidad

    def action_facturar_venta(self):
        """Acción para cambiar el estado de la venta a 'Facturado'."""
        self.ensure_one()
        if self.state == 'vendido':
            self.state = 'facturado'
        else:
            raise UserError("Solo las ventas en estado 'Vendido' pueden ser facturadas.")

    def action_cancelar_venta(self):
        """Acción para cambiar el estado de la venta a 'Cancelado'."""
        self.ensure_one()
        if self.state in ['vendido', 'facturado']:
            self.state = 'cancelado'

        else:
            raise UserError("Solo las ventas en estado 'Vendido' o 'Facturado' pueden ser canceladas.")
