from odoo import models, fields

class rsm_caracteristicas_lotes(models.Model):
    _name = "rsm.caracteristicas_lotes"
    _description = "Modelo para las características que pueden tener los lotes de productos"

    name = fields.Char('Nombre', required=True)
    color = fields.Integer('Color')

    # RESTRICCIONES
    _sql_constraints = [
        ('name_uniq', 'unique(name)', 'El nombre de la característica debe ser único.')
    ]
