from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import timedelta


class rsm_lotes(models.Model):
    _name = 'rsm.lotes'
    _description = 'Gestión de Lotes de Productos'
    _order = 'codigo asc'

    name = fields.Char(string='Nombre', required=True)
    codigo = fields.Char(string='Código', required=True, default=lambda self: self._default_codigo(), copy=False)
    cantidad_total = fields.Float(string='Cantidad Total', default=50.0)
    cantidad_pendiente = fields.Float(string='Cantidad Pendiente', compute='_compute_cantidad_pendiente', store=True, readonly=True)
    unidad_medida = fields.Selection([
        ('kg', 'Kilogramo'),
        ('lt', 'Litro'),
        ('dz', 'Docena'),
        ('mnj', 'Manojo'),
        ('cj', 'Caja'),
        ('rcp', 'Recipiente')
    ], string='Unidad de Medida', default='kg')
    fecha_compra = fields.Date(string='Fecha de Compra', default=fields.Date.context_today, copy=False)
    fecha_caducidad = fields.Date(string='Fecha de Caducidad', compute='_compute_fecha_caducidad', inverse='_inverse_fecha_caducidad', store=True)
    caducidad = fields.Integer(string='Días hasta Caducidad', default=1000)
    precio_compra = fields.Float(string='Precio de Compra')
    precio_compra_unidad = fields.Float(string='Precio Compra por Unidad', compute='_compute_precio_compra_unidad', readonly=True)
    precio_venta = fields.Float(string='Precio de Venta', compute='_compute_precio_venta', store=True)
    precio_venta_unidad = fields.Float(string='Precio Venta por Unidad', compute='_compute_precio_venta_unidad', readonly=True)
    recibido = fields.Boolean(string='Recibido', default=False)
    almacenado = fields.Boolean(string='Almacenado', default=False)
    state = fields.Selection([
        ('entero', 'Entero'),
        ('vendiendo', 'Vendiendo'),
        ('vendido', 'Vendido'),
        ('estropeado', 'Estropeado'),
        ('cancelado', 'Cancelado')
    ], string='Estado', required=True, default='entero')

    # Relaciones
    producto_id = fields.Many2one('rsm.productos', string='Producto', ondelete='cascade')
    caracteristicas_ids = fields.Many2many('rsm.caracteristicas_lotes', string='Características')
    ventas_ids = fields.One2many('rsm.ventas_lotes', 'lote_id', string='Ventas')


    @api.model
    def _default_codigo(self):
        return '{}-{}'.format(self.env.user.id, fields.Datetime.now().strftime('%Y%m%d%H%M'))

    @api.depends('producto_id', 'ventas_ids.cantidad_vendida')
    def _compute_cantidad_pendiente(self):
        for record in self:
            total_vendido = sum(venta.cantidad_vendida for venta in record.ventas_ids)
            record.cantidad_pendiente = record.cantidad_total - total_vendido

    @api.depends('fecha_compra', 'caducidad')
    def _compute_fecha_caducidad(self):
        for record in self:
            if record.fecha_compra:
                record.fecha_caducidad = record.fecha_compra + timedelta(days=record.caducidad)

    def _inverse_fecha_caducidad(self):
        for record in self:
            if record.fecha_compra and record.fecha_caducidad:
                record.caducidad = (record.fecha_caducidad - record.fecha_compra).days

    @api.depends('precio_compra', 'cantidad_total')
    def _compute_precio_compra_unidad(self):
        for record in self:
            if record.cantidad_total:
                record.precio_compra_unidad = record.precio_compra / record.cantidad_total

    @api.depends('precio_compra')
    def _compute_precio_venta(self):
        for record in self:
            record.precio_venta = record.precio_compra * 1.30

    @api.depends('precio_venta', 'cantidad_total')
    def _compute_precio_venta_unidad(self):
        for record in self:
            if record.cantidad_total:
                record.precio_venta_unidad = record.precio_venta / record.cantidad_total

    def action_vender_lote(self):
        self.ensure_one()
        self.state = 'vendido'

    def action_cancelar_lote(self):
        self.ensure_one()
        self.state = 'cancelado'

    @api.constrains('recibido', 'almacenado')
    def check_almacenado_when_recibido(self):
        for record in self:
            if record.recibido and not record.almacenado:
                raise ValidationError("El campo 'Almacenado' debe estar marcado si 'Recibido' es verdadero.")