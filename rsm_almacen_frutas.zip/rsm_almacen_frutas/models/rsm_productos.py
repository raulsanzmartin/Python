from odoo import models, fields

class rsm_productos(models.Model):
    _name = "rsm.productos"
    _description = "Modelo para los productos del almacén de frutas"
    _order = 'name asc'

    name = fields.Char('Nombre', required=True)
    lotes_ids = fields.One2many("rsm.lotes", "producto_id", string="Lotes Asociados")
    temporada = fields.Selection([
        ('primavera', 'Primavera'),
        ('verano', 'Verano'),
        ('otono', 'Otoño'),
        ('invierno', 'Invierno'),
        ('todo_el_ano', 'Todo el año')
    ], string='Temporada', default='todo_el_ano')
    alergeno = fields.Boolean(string='Alergeno', default=False)
    lote_ids = fields.One2many('rsm.lotes', 'producto_id', string='Lotes Relacionados')

    # RESTRICCIONES
    _sql_constraints = [
        ('name_uniq', 'unique(name)', 'El nombre del producto debe ser único.')
    ]
