from odoo import models, fields, Command

class rsm_inheritedVentasLotes(models.Model):
    _inherit = "rsm.ventas_lotes"

    def action_facturar_venta(self):
        account_move = self.env['account.move']
        for record in self:
            invoice_lines = [
                Command.create({
                    "name": "{} ({})".format(record.lote_id.name, record.lote_id.codigo),
                    "quantity": record.cantidad_vendida,
                    "price_unit": record.precio_total / record.cantidad_vendida,
                }),
                Command.create({
                    "name": "Portes",
                    "quantity": 1,
                    "price_unit": 30,
                })
            ]
            account_move.create({
                "partner_id": record.cliente_id.id,
                "move_type": "out_invoice",
                "journal_id": 1,
                "invoice_date": fields.Date.today(),
                "invoice_line_ids": invoice_lines,
            })
        # Asegúrate de llamar al super si el método original de 'action_facturar_venta'
        # en el modelo base 'rsm.ventas_lotes' debe ser ejecutado.
        # Si el método original no necesita ser ejecutado, puedes omitir la siguiente línea.
        return super(rsm_inheritedVentasLotes, self).action_facturar_venta()
