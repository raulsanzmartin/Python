{
    'name': 'Contabilidad de Almacén de Frutas',
    'summary': 'Módulo de contabilidad para enlace de almacén de frutas',
    'description': "Este módulo permite crear facturas al vender lotes de frutas",
    'license': 'LGPL-3',
    'depends': [
        'base',
        'rsm_almacen_frutas',
        'account',
    ],
    'data': [



],

    'application': True
}
